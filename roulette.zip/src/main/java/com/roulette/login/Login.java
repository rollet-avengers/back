package com.roulette.login;

public class Login {
    private static Long id;
}
