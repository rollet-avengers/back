package com.roulette.roulette.aboutlogin.exceptions;

public class RefreshNullException extends RuntimeException{
}
