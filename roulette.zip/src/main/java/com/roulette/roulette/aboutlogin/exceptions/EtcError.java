package com.roulette.roulette.aboutlogin.exceptions;

public class EtcError extends RuntimeException{
}