package com.roulette.roulette;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RouletteApplicationTests {

	@Test
	void contextLoads() {
	}

}
